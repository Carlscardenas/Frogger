package frogger.panel;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StatsPanel extends JPanel{
	
	private JLabel timeLabel, distanceLabel, coinsLabel;
	private JButton resetButton;
	
	public StatsPanel() {
		// TODO Auto-generated constructor stub
	}

}
